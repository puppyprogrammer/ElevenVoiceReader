export { getSettings, setSettings } from './storage.js';
export { playAudio, stopAudio, getCurrentAudio } from './audio.js';